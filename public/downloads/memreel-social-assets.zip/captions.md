# MemReel — Captured ≠ Remembered

## Shared campaign idea

A photo preserves what the moment looked like. MemReel asks what the photograph could not hold.

**Primary action:** Preserve one memory

---

## Instagram feed

### Main post

You saved the photo.

But do you remember what she said? What made you laugh? The name she gave the blanket fort?

A photo can keep the room, the faces, the light. It cannot remember the moment for you.

Preserve one memory while it is still yours to tell.

**CTA:** Preserve one memory

### Alternate short caption

The picture stayed. The small details didn’t.

Choose one photo. Add what it cannot show.

**CTA:** Preserve one memory

### Story sequence

1. **Frame 1:** A photo can’t remember for you.
2. **Frame 2:** What did this photo leave out?
3. **Frame 3:** Choose one. Preserve what you still remember.
4. **Link text:** Preserve one memory

---

## LinkedIn founder post

We take thousands of photos of our children.

I have been thinking about what those photos actually preserve.

They hold the light, the faces, the room. But years later, they may not tell us what our child had just said, why everyone was laughing, or the strange little name they gave that afternoon.

The picture stayed. The story became harder to reach.

We built a small MemReel experiment around that gap. It does not ask you to document everything. It asks you to choose one ordinary photo and add the detail the image could not hold.

If you try it, the meaningful signal for us is not a like. It is whether one real photo brings one real memory forward.

**CTA:** Preserve one memory

---

## Blog post

# A photo can’t remember for you

There is a particular kind of photograph in every parent’s camera roll.

Nothing important seems to be happening. A blanket fort. Breakfast half-finished. A walk around the block. Your child is laughing at something just outside the frame.

The photograph keeps the visible parts. The light in the room. The clothes they wore. The way they tilted their head.

But try to answer a smaller question: what had they just said?

That is where the photograph becomes incomplete.

We often treat capture as memory. We assume that because the picture stayed, the moment did too. But a picture cannot preserve the joke, the invented word, the reason everyone was laughing, or the feeling of being there unless someone gives those details a place to live.

This is not an argument for recording everything. Parents already carry enough pressure.

It is an invitation to preserve one.

Choose one ordinary photograph. Add what was happening. Write down the phrase, feeling, or tiny detail you still remember. If there is something the photo cannot show and you can no longer retrieve, leave it blank.

The blank matters too. It shows us what an image can hold—and what it cannot.

**CTA:** Preserve one memory

---

## Measurement notes

Count as strong signals:

- A parent chooses and uploads a real photo.
- A parent contributes a phrase, feeling, or story detail.
- A parent finishes the private preservation flow.

Do not treat likes, saves, or general agreement as proof of the hypothesis.
