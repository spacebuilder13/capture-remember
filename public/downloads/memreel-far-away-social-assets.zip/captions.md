## Instagram feed

Three cushions high. Then he turned round to show someone.

The photo gets to Pop Pop. The shout, the wobble, the look on his face just before usually don't.

MemReel turns one photo and a few words into the moment, written the way you'd tell it.

Pick one moment that didn't quite travel.

## Instagram story

Frame 1: He turned round to show someone.

Frame 2: Four thousand miles away, Pop Pop was already clapping.

Frame 3: Send the photo and what happened right before it.

Link text: Try it with one photo

## LinkedIn

Families with grandparents far away send a lot of photos. In our conversations with parents, the same thing kept coming up: the photo arrives, but the story around it doesn't.

What they said right before. Why it was funny. The bit you'd tell if you were in the same room.

So we built a small MemReel experiment. You choose one photo, tap a prompt, and add a few words. MemReel writes it up for the person it's for, using only your facts, and you check it before anything is saved.

The signal we care about: does the parent say "this is right" and keep it?